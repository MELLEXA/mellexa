var typed = new Typed('.typed', {
  strings: [
    '<span class="grad0">Диагностика</span>',
    '<span class="grad1">Ремонт</span>',
    '<span class="grad2">Обслуживание</span>',
    '<span class="grad3">Оригинальные запчасти</span>',
    '<span class="grad4">Команда профессионалов</span>',
    '<span class="grad5">Современное оборудование</span>',
    '<span class="grad6">Гарантия результата</span>',
    '<span class="grad7">Демократичные цены</span>',
    '<span class="grad8">Высшее качество</span>'
  ],
  typeSpeed: 50,
  backSpeed: 30,
  backDelay: 3000,
  loop: true,
})


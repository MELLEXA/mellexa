function nav_main(hrf) {

 document.write('<div class="nav-scroller">');
 document.write('<nav class="nav-scroller__items dragscroll">');

 if(hrf=="main") {
   document.write('<a href="#" class="nav-scroller__item nav-scroller__item_active">Главная</a>');
 }
 else {
  document.write('<a href="/" class="nav-scroller__item">Главная</a>');
 }
  if(hrf=="teachers") {
   document.write('<a href="#" class="nav-scroller__item  nav-scroller__item_active">Наши мастера</a>');
  }
  else {
   document.write('<a href="/teachers" class="nav-scroller__item">Наши мастера</a>');
 }
  if(hrf=="disciplines") {
    document.write(' <a href="#" class="nav-scroller__item   nav-scroller__item_active">Услуги</a>');
   }
  else {
   document.write(' <a href="/disciplines" class="nav-scroller__item">Услуги</a>');
  }
  if(hrf=="materials") {
     document.write('<a href="#" class="nav-scroller__item nav-scroller__item_active">Наши работы</a>');
   }
   else {
   document.write('<a href="/materials" class="nav-scroller__item">Наши работы</a>');
  }
  if(hrf=="students") {
     document.write('<a href="#" class="nav-scroller__item nav-scroller__item_active">Отзывы</a>');
  }
  else {
   document.write('<a href="/students" class="nav-scroller__item">Отзывы</a>');
  }
    if(hrf=="abitur") {
      document.write('<a href="#" class="nav-scroller__item nav-scroller__item_active">Блог</a>');
     }
    else {
    document.write('<a href="/abitur" class="nav-scroller__item">Блог</a>');
    }
      if(hrf=="contacts") {
          document.write('<a href="#" class="nav-scroller__item nav-scroller__item_active">Контакты</a>');
       }
       else {
       document.write('<a href="/contacts" class="nav-scroller__item">Контакты</a>');
       }
 document.write('</nav>');
 document.write('</div>');
}

sudo npm install pm2@latest -g - установка
pm2 start app.js - start
pm2 list - список
pm2 stop - остановка
открытые порты 8083-8089
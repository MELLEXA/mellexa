Если в текущей папке НЕТ подпапки "node_modules", то 
перейдити в терминале (например, в Cmd) в папку проекта и выполните установки:

npm install --save @dotlottie/player-component

npm install express